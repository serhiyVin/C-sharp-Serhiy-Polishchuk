﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class UserUpdateConflictForm : Form
    {
        public UserUpdateConflictForm(int StudentID,string LastName)
        {
            InitializeComponent();
            txtLastName.Text = LastName;
            txtID.Text += StudentID.ToString();
        }
    }
}
