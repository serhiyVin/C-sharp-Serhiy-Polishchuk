using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class AuthentFrm : Form
    {
        string login;
        string password;
        public AuthentFrm()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            login = txtLogin.Text;
            password = txtPwd.Text;
        }
        public string Login
        { get { return login; } }
        public string Password
        { get { return password; } }
    }
}