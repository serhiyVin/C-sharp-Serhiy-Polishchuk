﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class SubjectEditConflictForm : Form
    {
        public SubjectEditConflictForm(int subjectID, string titleOrig, string titleEntered, string titleCurrDB)
        { 
            InitializeComponent();
            lblID.Text += subjectID.ToString();
            txtTitleOrig.Text = titleOrig;
            txtTitleEntered.Text = titleEntered;
            txtCurrDB.Text = titleCurrDB;
        }
    }
}
