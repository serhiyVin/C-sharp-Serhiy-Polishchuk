﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class SubjectUpdateConflictForm : Form
    {
        public SubjectUpdateConflictForm()
        {
            InitializeComponent();
        }
        public SubjectUpdateConflictForm(int SubjectID, string Title)
        {
            InitializeComponent();
            txtID.Text = SubjectID.ToString();
            txtTitle.Text = Title;
        }
    }
}
