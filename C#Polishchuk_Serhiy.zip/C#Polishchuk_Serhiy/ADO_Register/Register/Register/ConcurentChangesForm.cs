﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class ConcurentChangesForm : Form
    {

        public ConcurentChangesForm(DataTable tConcurrentRates,DataTable tConcurrentUsers,DataTable tConcurrentSubjects)
        {
            InitializeComponent();
            gridRates.DataSource = tConcurrentRates;
            gridRates.Sort(gridRates.Columns[0], ListSortDirection.Ascending);
            gridUsers.DataSource = tConcurrentUsers;
            gridSubjects.DataSource = tConcurrentSubjects;
        }
    }
}
