﻿namespace Class_Register
{
    partial class SubjectEditConflictForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
         
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOverwrite = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.btnSkip = new System.Windows.Forms.Button();
            this.txtTitleOrig = new System.Windows.Forms.TextBox();
            this.txtTitleEntered = new System.Windows.Forms.TextBox();
            this.txtCurrDB = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOverwrite
            // 
            this.btnOverwrite.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOverwrite.Location = new System.Drawing.Point(33, 233);
            this.btnOverwrite.Name = "btnOverwrite";
            this.btnOverwrite.Size = new System.Drawing.Size(75, 23);
            this.btnOverwrite.TabIndex = 0;
            this.btnOverwrite.Text = "Overwrite";
            this.btnOverwrite.UseVisualStyleBackColor = true;
            // 
            // btnRestore
            // 
            this.btnRestore.DialogResult = System.Windows.Forms.DialogResult.Retry;
            this.btnRestore.Location = new System.Drawing.Point(157, 233);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(75, 23);
            this.btnRestore.TabIndex = 1;
            this.btnRestore.Text = "Restore";
            this.btnRestore.UseVisualStyleBackColor = true;
            // 
            // btnSkip
            // 
            this.btnSkip.DialogResult = System.Windows.Forms.DialogResult.Ignore;
            this.btnSkip.Location = new System.Drawing.Point(285, 233);
            this.btnSkip.Name = "btnSkip";
            this.btnSkip.Size = new System.Drawing.Size(75, 23);
            this.btnSkip.TabIndex = 2;
            this.btnSkip.Text = "Skip";
            this.btnSkip.UseVisualStyleBackColor = true;
            // 
            // txtTitleOrig
            // 
            this.txtTitleOrig.Location = new System.Drawing.Point(97, 30);
            this.txtTitleOrig.Name = "txtTitleOrig";
            this.txtTitleOrig.ReadOnly = true;
            this.txtTitleOrig.Size = new System.Drawing.Size(212, 20);
            this.txtTitleOrig.TabIndex = 3;
            // 
            // txtTitleEntered
            // 
            this.txtTitleEntered.Location = new System.Drawing.Point(97, 73);
            this.txtTitleEntered.Name = "txtTitleEntered";
            this.txtTitleEntered.ReadOnly = true;
            this.txtTitleEntered.Size = new System.Drawing.Size(212, 20);
            this.txtTitleEntered.TabIndex = 4;
            // 
            // txtCurrDB
            // 
            this.txtCurrDB.Location = new System.Drawing.Point(97, 116);
            this.txtCurrDB.Name = "txtCurrDB";
            this.txtCurrDB.ReadOnly = true;
            this.txtCurrDB.Size = new System.Drawing.Size(212, 20);
            this.txtCurrDB.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCurrDB);
            this.groupBox1.Controls.Add(this.txtTitleEntered);
            this.groupBox1.Controls.Add(this.txtTitleOrig);
            this.groupBox1.Location = new System.Drawing.Point(27, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(333, 163);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Current in DB";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Entered";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Original";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(373, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "The title of this subject was already modified by another user";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(24, 28);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(57, 13);
            this.lblID.TabIndex = 8;
            this.lblID.Text = "SubjectID:";
            // 
            // SubjectEditConflictForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 276);
            this.ControlBox = false;
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSkip);
            this.Controls.Add(this.btnRestore);
            this.Controls.Add(this.btnOverwrite);
            this.Name = "SubjectEditConflictForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Conflict action";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOverwrite;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button btnSkip;
        private System.Windows.Forms.TextBox txtTitleOrig;
        private System.Windows.Forms.TextBox txtTitleEntered;
        private System.Windows.Forms.TextBox txtCurrDB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblID;
    }
}