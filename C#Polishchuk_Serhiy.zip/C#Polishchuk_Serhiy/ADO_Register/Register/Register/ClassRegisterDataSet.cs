﻿namespace Class_Register
{


    public partial class ClassRegisterDataSet {
    }
}

namespace Class_Register.ClassRegisterDataSetTableAdapters {
    using System.Data;
    using System.Data.SqlClient;   
    
    public partial class UsersTableAdapter {
    }
}
