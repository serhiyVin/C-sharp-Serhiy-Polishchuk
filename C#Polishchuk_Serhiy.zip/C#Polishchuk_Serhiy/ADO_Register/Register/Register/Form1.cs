﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class Mainframe : Form
    {
        private  DataLayer dLayer;
        public Mainframe()
        {
            ReportsErr frm = new ReportsErr();
            InitializeComponent();
            dLayer = new DataLayer();
            SubjectsBindingSource.DataSource = dLayer.ClassRegDataSet;
            SubjectsBindingSource.DataMember = "Subjects";
            cmbSubjects.DataSource = SubjectsBindingSource;
            cmbSubjects.DisplayMember = "Title";
            cmbSubjects.ValueMember = "SubjectID";
            cmbSubjects.DataBindings.Add("SelectedValue", SubjectsBindingSource, "SubjectID");
            BindingSource.DataSource = dLayer.ClassRegDataSet;
            BindingSource.DataMember = "Register";
            txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BindingSource, "Last name", true));
            txtUserID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BindingSource, "ID", true));
            gridView.DataSource = BindingSource;
            gridView.Columns[0].ReadOnly = true;
            gridView.Columns[1].ReadOnly = true;
            dLayer.conflManager.UserEditConflict += new EventHandler<UserEditEventArgs>(ConflictManager_UserEditConflict);
            dLayer.conflManager.UserUpdateConflict += new EventHandler<UserUpdateEventArgs>(conflManager_UserUpdateConflict);
            dLayer.conflManager.GradeReportUpdateConflict += new EventHandler<GradeReportEventArgs>(conflManager_GradeReportUpdateConflict);
            dLayer.conflManager.SubjectEditConflict += new EventHandler<SubjectEditEventArgs>(conflManager_SubjectEditConflict);
            dLayer.conflManager.SubjectUpdateConflict += new EventHandler<SubjectUpdateEventArgs>(conflManager_SubjectUpdateConflict);
        }

        void conflManager_SubjectUpdateConflict(object sender, SubjectUpdateEventArgs e)
        {
            SubjectUpdateConflictForm frm = new SubjectUpdateConflictForm(e.SubjectID, e.Title);
            if (frm.ShowDialog() == DialogResult.OK)
                dLayer.conflManager.action = ConflictManager.Action.restore;
            else
                dLayer.conflManager.action = ConflictManager.Action.skip;
        }

        void conflManager_SubjectEditConflict(object sender, SubjectEditEventArgs e)
        {
            SubjectEditConflictForm frm = new SubjectEditConflictForm(e.SubjectID, e.OriginalTitle, e.EnteredTitle, e.TitleInDB);
            DialogResult result = frm.ShowDialog();
            if(result== DialogResult.OK)
                ((ConflictManager)sender).action = ConflictManager.Action.overwrite;
            else if (result == DialogResult.Retry)
                ((ConflictManager)sender).action = ConflictManager.Action.restore;
            else if (result == DialogResult.Ignore)
                ((ConflictManager)sender).action = ConflictManager.Action.skip;
        }

        void conflManager_GradeReportUpdateConflict(object sender, GradeReportEventArgs e)
        {
            ConcurentChangesForm frm = new ConcurentChangesForm(e.ConcurentRates,e.UsersDeleted,e.SubjectsDeleted);
            frm.ShowDialog();
        }

        void conflManager_UserUpdateConflict(object sender, UserUpdateEventArgs e)
        {
            UserUpdateConflictForm frm=new UserUpdateConflictForm (e.StudentID,e.LastName);
            DialogResult result = frm.ShowDialog();
            if (result == DialogResult.OK)
                ((ConflictManager)sender).action = ConflictManager.Action.restore;
            else if (result == DialogResult.Ignore)
                ((ConflictManager)sender).action = ConflictManager.Action.skip;
        }

        void ConflictManager_UserEditConflict(object sender, UserEditEventArgs e)
        {
            UserEditConflictForm frm = new UserEditConflictForm(e.StudentID,e.OrigLName, e.ModifLName, e.CurrLName);
            DialogResult result=frm.ShowDialog();
            if (result == DialogResult.OK)
                ((ConflictManager)sender).action = ConflictManager.Action.overwrite;
            else if (result == DialogResult.Retry)
                ((ConflictManager)sender).action = ConflictManager.Action.restore;
            else if (result == DialogResult.Ignore)
                ((ConflictManager)sender).action = ConflictManager.Action.skip;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dLayer.SubmitChanges();
        }

        private void btnAddSubj_Click(object sender, EventArgs e)
        {
            NewSubjectForm frm = new NewSubjectForm();
            if (frm.ShowDialog() == DialogResult.OK)
                if (frm.txtTitle.Text != "")
                    dLayer.AddNewSubjects(frm.txtTitle.Text);
        }

        private void btnDelSubj_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)SubjectsBindingSource.Current;
            if (r != null)
                dLayer.DeleteSubject((int)r["SubjectID"]);
        }

        private void btnEditStudent_Click(object sender, EventArgs e)
        {
            EditStudentForm frm = new EditStudentForm(((DataRowView)BindingSource.Current)["ID"].ToString(), ((DataRowView)BindingSource.Current)["Last name"].ToString());
            if (frm.ShowDialog() == DialogResult.OK)
                if (frm.EditedName != "")
                    dLayer.EditLastName((int)((DataRowView)BindingSource.Current)["ID"], frm.EditedName);
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            NewStudentForm frm = new NewStudentForm();
            if (frm.ShowDialog() == DialogResult.OK)
                if(frm.txtLastName.Text!="")
                    dLayer.AddNewStudent(frm.txtLastName.Text);
        }

        private void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            DataRowView r = (DataRowView)BindingSource.Current;
            if (r != null)
                dLayer.DeleteStudent((int)r["ID"]);
        }

        private void btnEditSubject_Click(object sender, EventArgs e)
        {
            SubjectEditForm frm = new SubjectEditForm(((DataRowView)SubjectsBindingSource.Current)["SubjectID"].ToString(), ((DataRowView)SubjectsBindingSource.Current)["Title"].ToString());
            if (frm.ShowDialog() == DialogResult.OK)
                if (frm.EditedTitle!= "")
                    dLayer.EditSubject((int)((DataRowView)SubjectsBindingSource.Current)["SubjectID"], frm.EditedTitle);
        }

    }
}
