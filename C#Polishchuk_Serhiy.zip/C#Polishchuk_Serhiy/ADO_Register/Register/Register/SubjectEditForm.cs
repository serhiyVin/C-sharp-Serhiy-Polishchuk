﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class SubjectEditForm : Form
    {
        public SubjectEditForm()
        {
            InitializeComponent();
        }
        public SubjectEditForm(string subjectID, string Title)
        {
            InitializeComponent();
            this.txtID.Text = subjectID;
            this.txtTitle.Text = Title;
        }
        public string EditedTitle
        { get { return txtTitle.Text; } }

        private void txtTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnOK.PerformClick();
            }
        }
    }
}
