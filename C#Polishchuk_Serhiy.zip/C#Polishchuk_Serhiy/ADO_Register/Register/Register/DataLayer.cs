﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{

    public partial class DataLayer : Component
    {
        //
        public ConflictManager conflManager;
        private DataTable tblRegister;
        private ClassRegisterDataSet.UsersDataTable tblUsers;
        private ClassRegisterDataSet.SubjectsDataTable tblSubjects;
        private ClassRegisterDataSet.GradeReportDataTable tblGradeReport;
        private DataTable tConflRates;

        private string[] subjects;
        public DataLayer()
        {
            InitializeComponent();
            conflManager = new ConflictManager();
            tConflRates = new ClassRegisterDataSet.GradeReportDataTable();
            FillDataSet();
            tblRegister = CreateRegister();
            classRegDs.Tables.Add(tblRegister);
            tblUsers = classRegDs.Users;
            tblSubjects = classRegDs.Subjects;
            tblGradeReport = classRegDs.GradeReport;
            usersTableAdapter.Adapter.RowUpdated += new SqlRowUpdatedEventHandler(usersAdapter_RowUpdated);
            //subjects = GetSubjectsArr();
        }
        public DataLayer(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
        }
        public ClassRegisterDataSet ClassRegDataSet
        {
            get { return classRegDs; }
        }

        void usersAdapter_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
        {
            if ((e.Status == UpdateStatus.Continue) && (e.StatementType == StatementType.Insert))
            {
                DataRow r = tblRegister.Rows.Find(e.Row["UserID", DataRowVersion.Original]);
                r["ID"] = e.Row["UserID", DataRowVersion.Current];
                r.AcceptChanges();
            }
        }

        private void FillDataSet()
        {
            usersTableAdapter.Fill(classRegDs.Users);
            subjectsTableAdapter.Fill(classRegDs.Subjects);
            gradeReportTableAdapter.Fill(classRegDs.GradeReport);
        }
        private DataTable CreateRegister()
        {
            DataTable tbl = new DataTable("Register");
            DataColumn clm = new DataColumn("ID", typeof(int));
            clm.AutoIncrement = true;
            clm.AutoIncrementSeed = 1;
            clm.AutoIncrementStep = 1;
            tbl.Columns.Add(clm);
            tbl.Columns.Add("Last name", typeof(string));
            DataColumn[] keyCol = new DataColumn[1];
            keyCol[0] = tbl.Columns["ID"];
            tbl.PrimaryKey = keyCol;
            tbl.Columns["Last name"].AllowDBNull = false;
            foreach (string s in GetSubjectsArr())
            {
                tbl.Columns.Add(s, typeof(int));
            }
            FillRegister(tbl);
            return tbl;
        }
        private void FillRegister(DataTable tbl)
        {
            string strSql = "select userID,LastName from Users Where Role='student'";
            try
            {
                cn.Open();
                using (SqlDataReader rdr = new SqlCommand(strSql, cn).ExecuteReader())
                {
                    while (rdr.Read())
                        tbl.Rows.Add(new object[] { (int)rdr.GetValue(0), (string)rdr.GetValue(1) });
                }
                strSql = "select u.UserID, s.title,gr.Rate "
                            + "from Users u "
                            + "join gradereport gr "
                            + "on u.userid=gr.userid "
                            + "join subjects s "
                            + "on s.subjectid=gr.subjectid";
                using (SqlDataReader rdr = new SqlCommand(strSql, cn).ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        tbl.Rows.Find((int)rdr[0])[(string)rdr[1]] = rdr[2];
                    }
                }
                tbl.AcceptChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        public string[] GetSubjectsArr()
        {
            string[] subjects = new string[classRegDs.Subjects.Rows.Count];
            for (int i = 0; i < classRegDs.Subjects.Rows.Count; i++)
                subjects[i] = classRegDs.Subjects[i]["Title"].ToString();
            return subjects;
        }
        public void SubmitChanges()
        {
            UpdateModified();
        }
        private void UpdateModified()
        {
            DataRow[] rowsModified = tblRegister.Select("", "", DataViewRowState.ModifiedCurrent);
            if (rowsModified.Length != 0)
            {
                ClassRegisterDataSet.GradeReportRow r;
                for (int i = 0; i < rowsModified.Length; i++)
                    for (int j = 0; j < tblSubjects.Rows.Count; j++)
                    {
                        r = tblGradeReport.FindByUserIDSubjectID((int)rowsModified[i]["ID"], (int)tblSubjects.Rows[j]["SubjectID"]);
                        if (r != null)
                        {
                            if ((r["Rate"].GetType() == typeof(int)) && r["Rate"].GetType() == rowsModified[i][(string)tblSubjects.Rows[j]["Title"]].GetType())
                            {
                                if ((int)r["Rate"] != (int)rowsModified[i][(string)tblSubjects.Rows[j]["Title"]])
                                    r["Rate"] = rowsModified[i][(string)tblSubjects.Rows[j]["Title"]];
                            }
                            else if (r["Rate"].GetType() != rowsModified[i][(string)tblSubjects.Rows[j]["Title"]].GetType())
                                r["Rate"] = rowsModified[i][(string)tblSubjects.Rows[j]["Title"]];
                        }
                        else if (r == null && (rowsModified[i][(string)tblSubjects.Rows[j]["Title"]]).GetType() != typeof(System.DBNull))
                        {
                            r = tblGradeReport.NewGradeReportRow();
                            r["UserID"] = rowsModified[i]["ID"];
                            r["SubjectID"] = tblSubjects.Rows[j]["SubjectID"];
                            r["Rate"] = rowsModified[i][(string)tblSubjects.Rows[j]["Title"]];
                            tblGradeReport.Rows.Add(r);
                        }
                    }
                gradeReportTableAdapter.Adapter.ContinueUpdateOnError = true;
                gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Added));
                gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.ModifiedCurrent));
                DataRow[] rowsInError = tblGradeReport.GetErrors();
                if (rowsInError.Length > 0)
                {
                    DataTable tUsersDeleted = FindDeletedUsers(rowsInError);
                    DataTable tSubjDeleted = FindDeletedSubjects(rowsInError);
                    ClassRegisterDataSet.GradeReportDataTable tGrReportDB = new ClassRegisterDataSet.GradeReportDataTable();
                    DataTable tConflictRates = FindConlictRates(rowsInError, tGrReportDB);
                    conflManager.GrReportUpdateConflict(tConflictRates, tUsersDeleted,tSubjDeleted);
                    foreach (DataRow subjDeleted in tSubjDeleted.Rows)
                    {
                        if ((bool)subjDeleted["Restore"] == true)
                        {
                            ClassRegisterDataSet.SubjectsRow subjToRestore = tblSubjects.FindBySubjectID((int)subjDeleted["SubjectID"]);
                            subjToRestore.SetAdded();
                            foreach (DataRow ratesToRestore in subjToRestore.GetChildRows("FK_GradeReport_Subjects"))
                            {
                                ratesToRestore.AcceptChanges();
                                ratesToRestore.SetAdded();
                            }
                            subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.Added));
                            gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Added));
                        }
                        else
                        {
                            ClassRegisterDataSet.SubjectsRow subjToDelete = tblSubjects.FindBySubjectID((int)subjDeleted["SubjectID"]);
                            tblRegister.Columns.Remove((string)subjToDelete["Title"]);
                            foreach (DataRow ratesToDelete in subjToDelete.GetChildRows("FK_GradeReport_Subjects"))
                            {
                                tblGradeReport.Rows.Remove(ratesToDelete);
                            }
                            tblSubjects.Rows.Remove(subjToDelete);
                        }
                    }
                    foreach (DataRow userDeleted in tUsersDeleted.Rows)
                    {
                        if ((bool)userDeleted["Restore"] == true)
                        {
                            ClassRegisterDataSet.UsersRow userToRestore = tblUsers.FindByUserID((int)userDeleted["ID"]);
                            userToRestore.SetAdded();
                            foreach (DataRow rowToAdd in userToRestore.GetChildRows("FK_GradeReport_User"))
                            {
                                rowToAdd.AcceptChanges();
                                rowToAdd.SetAdded();
                            }
                            usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.Added));
                            gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Added));
                        }
                        else
                        {
                            ClassRegisterDataSet.UsersRow userToDelete = tblUsers.FindByUserID((int)userDeleted["ID"]);
                            DataRow rReg = tblRegister.Rows.Find(userToDelete["UserID"]);
                            tblRegister.Rows.Remove(rReg);
                            foreach (DataRow rateToDel in userToDelete.GetChildRows("FK_GradeReport_User"))
                            {
                                tblGradeReport.Rows.Remove(rateToDel);
                            }
                            tblUsers.Rows.Remove(userToDelete);
                        }
                    }
                    foreach (DataRow row in tConflictRates.Rows)
                    {
                        if ((bool)row["Overwrite"] == false)
                        {
                            ClassRegisterDataSet.GradeReportRow grDB = tGrReportDB.FindByUserIDSubjectID((int)row["ID"], (int)GetIDByTitle((string)row["Subject"]));////!!!
                            ClassRegisterDataSet.GradeReportRow grApp = tblGradeReport.FindByUserIDSubjectID((int)row["ID"], (int)GetIDByTitle((string)row["Subject"]));
                            grApp["Rate"] = grDB["Rate"];
                            grApp.ClearErrors();
                            grApp.AcceptChanges();
                            DataRow rowReg = tblRegister.Rows.Find(row["ID"]);
                            rowReg[(string)(tblSubjects.FindBySubjectID((int)grDB["SubjectID"])["Title"])] = grDB["Rate"];
                            tGrReportDB.Rows.Remove(grDB);
                        }
                        else
                        {
                            tblGradeReport.Merge(tGrReportDB, true);
                            gradeReportTableAdapter.Update(tGrReportDB);
                        }
                    }
                    UpdateModified();
                }
                //foreach (ClassRegisterDataSet.GradeReportRow r1 in tblGradeReport.GetErrors())
                //{
                //    r1.ClearErrors();
                //    r1.AcceptChanges();
                //}
                //tblRegister.AcceptChanges();
            }
            gradeReportTableAdapter.Adapter.ContinueUpdateOnError = false;
        }

        private DataTable CreateConflictRates()
        {
            DataTable tConflChanges = new DataTable();
            tConflChanges.Columns.Add("ID", typeof(int));
            tConflChanges.Columns["ID"].ReadOnly = true;
            tConflChanges.Columns.Add("Last name", typeof(string));
            tConflChanges.Columns["Last name"].ReadOnly = true;
            tConflChanges.Columns.Add("Subject", typeof(string));
            tConflChanges.Columns["Subject"].ReadOnly = true;
            tConflChanges.Columns.Add("Rate", typeof(string));
            tConflChanges.Columns["Rate"].ReadOnly = true;
            tConflChanges.Columns.Add("Rate in db", typeof(string));
            tConflChanges.Columns["Rate in db"].ReadOnly = true;
            tConflChanges.Columns.Add("Overwrite", typeof(bool));
            tConflChanges.Columns["Overwrite"].ReadOnly = false;
            return tConflChanges;
        }
        //метод, возвращающий таблицу представляющую инф. о конкурентных изменениях оценки студента
        //передается в уровень представления для определения того,нужно ли перезаписать текущие записи в бд
        private DataTable FindConlictRates(DataRow[] rowsInError,ClassRegisterDataSet.GradeReportDataTable tGrReportDB)
        {
            gradeReportTableAdapter.ClearBeforeFill = false;
            //таблица в которую будут записаны даные о конкурентных изменениях оценки
            DataTable tConflRates = CreateConflictRates();
            int rowsReturned;
            foreach(DataRow rInError in rowsInError)
            {
                rowsReturned = gradeReportTableAdapter.FillByUserIDSubjID(tGrReportDB, (int)rInError["UserID"], (int)rInError["SubjectID"]);
                if (rowsReturned == 1)
                {
                    DataRow r = tConflRates.NewRow();
                    r["ID"] = rInError["UserID"];
                    r["Last Name"] = tblUsers.FindByUserID((int)rInError["UserID"]).LastName;
                    r["Subject"] = tblSubjects.FindBySubjectID((int)rInError["SubjectID"]).Title;
                    r["Rate"] = rInError["Rate"];
                    r["Rate in db"] = tGrReportDB[0]["Rate"];
                    r["Overwrite"] = true;
                    tConflRates.Rows.Add(r);
                }
            }
            gradeReportTableAdapter.ClearBeforeFill = true;
            return tConflRates;
        }
        private DataTable CreateConflictUsers()
        {
            DataTable tUsersDeleted = new DataTable();
            DataColumn clm = new DataColumn("ID", typeof(int));
            clm.ReadOnly = true;
            DataColumn [] keyClm=new DataColumn[1];
            keyClm[0] = clm;
            tUsersDeleted.Columns.Add(clm);
            tUsersDeleted.PrimaryKey = keyClm;
            tUsersDeleted.Columns.Add("Last name", typeof(string));
            tUsersDeleted.Columns["Last name"].ReadOnly = true;
            tUsersDeleted.Columns.Add("Restore", typeof(bool));
            tUsersDeleted.Columns["Restore"].ReadOnly = false;
            return tUsersDeleted;
        }
        private DataTable CreateConflictSubjects()
        {
            DataTable tblConflSubjects= new DataTable();
            DataColumn clm = new DataColumn("SubjectID", typeof(int));
            clm.ReadOnly = true;
            DataColumn[] keyClm = new DataColumn[1];
            keyClm[0] = clm;
            tblConflSubjects.Columns.Add(clm);
            tblConflSubjects.PrimaryKey = keyClm;
            tblConflSubjects.Columns.Add("Title", typeof(string));
            tblConflSubjects.Columns["Title"].ReadOnly = true;
            tblConflSubjects.Columns.Add("Restore", typeof(bool));
            tblConflSubjects.Columns["Restore"].ReadOnly = false;
            return tblConflSubjects;
        }
        //метод, возвращающий таблицу с ID и фамилиями студентов,которые были удалены другим пользователем.
        //передается в уровень представления для определения того,нужно ли восстанавливать этих студентов
        private DataTable FindDeletedUsers(DataRow [] rowsInError)
        {
            usersTableAdapter.ClearBeforeFill = false;
            //таблица в которую будут записаны данные об удаленных студентах
            DataTable tblConflUsers = CreateConflictUsers();
            int rowsReturned;
            //перебор строк,обновление которых завершилось с ошибкой.
            foreach (DataRow r in rowsInError)
            {
                //если запись о студенте,которому соответствует строка с ошибкой в базе данных отсутствует,
                //то создается запись об этом студенте на овновании инф. из таблицы tblUsers приложения.
                //rowsReturned = usersTableAdapter.FillByID(tUsersDeleted, (int)r["UserID"]);
                rowsReturned = (int)usersTableAdapter.IfExist((int)r["UserID"]);
                if (rowsReturned ==0)
                {
                    DataRow row = tblConflUsers.NewRow();
                    row["ID"] = tblUsers.FindByUserID((int)r["UserID"])["UserID"];
                    row["Last name"] = tblUsers.FindByUserID((int)r["UserID"])["LastName"];
                    row["Restore"] = true;
                    if (!tblConflUsers.Rows.Contains(r["UserID"]))
                        tblConflUsers.Rows.Add(row);
                }
            }
            usersTableAdapter.ClearBeforeFill = true;
            return tblConflUsers;
        }
        //метод,возвращающий таблицу,представляющую инф. о предметах,которые были удалены другим пользователем
        //передается в уровень представления для определения того,нужно ли восстанавливать эти предметы
        private DataTable FindDeletedSubjects(DataRow[] rowsInErorr)
        {
            subjectsTableAdapter.ClearBeforeFill = false;
            DataTable tblConflSubjects = CreateConflictSubjects();
            int rowsReturned;
            //перебор строк,обновление которых завершилось с ошибкой.
            foreach (DataRow r in rowsInErorr)
            {
                rowsReturned = (int)subjectsTableAdapter.IfExist((int)r["SubjectID"]);
                if (rowsReturned == 0)
                {
                    DataRow row = tblConflSubjects.NewRow();
                    row["SubjectID"] = (int)r["SubjectID"];
                    row["Title"] = (string)tblSubjects.FindBySubjectID((int)r["SubjectID"])["Title"];
                    row["Restore"] = true;
                    if(!tblConflSubjects.Rows.Contains(r["SubjectID"]))
                        tblConflSubjects.Rows.Add(row);
                }
            }
            subjectsTableAdapter.ClearBeforeFill = true;
            return tblConflSubjects;
        }
        public void EditLastName(int ID, string NewLastName)
        {
            ClassRegisterDataSet.UsersRow userToEdit = tblUsers.FindByUserID(ID);
            if (userToEdit != null)
            {
                userToEdit["LastName"] = NewLastName;
                DataRow rowReg = tblRegister.Rows.Find(ID);
                rowReg["Last name"] = NewLastName;
                try
                {
                    usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.ModifiedCurrent));
                }
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.UsersDataTable t = new ClassRegisterDataSet.UsersDataTable();
                    int rowsReturned = usersTableAdapter.FillByID(t, (int)e.Row["UserID"]);
                    if (rowsReturned == 1)
                    {
                        conflManager.UserEditConflictOccured((int)e.Row["UserID"], e.Row["LastName", DataRowVersion.Original].ToString(), e.Row["LastName", DataRowVersion.Current].ToString(), t.Rows[0]["LastName"].ToString());
                        if (conflManager.action == ConflictManager.Action.overwrite)
                        {
                            tblUsers.Merge(t, true);
                            usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.ModifiedCurrent));
                        }
                        else if (conflManager.action == ConflictManager.Action.restore)
                        {
                            e.Row.RejectChanges();
                            tblUsers.Merge(t, true);
                            usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.ModifiedCurrent));
                            rowReg = tblRegister.Rows.Find(e.Row["UserID"]);
                            rowReg["Last name"] = e.Row["LastName"].ToString();
                        }
                        else if (conflManager.action == ConflictManager.Action.skip)
                        {
                            tblUsers.Merge(t, false);
                            rowReg = tblRegister.Rows.Find((int)e.Row["UserID"]);
                            rowReg["Last name"] = e.Row["LastName"].ToString();
                        }
                        conflManager.action = ConflictManager.Action.noAction;
                    }
                    else
                    {
                        conflManager.UserUpdateConflictOccured((int)e.Row["UserID"], (string)e.Row["LastName"]);
                        if (conflManager.action == ConflictManager.Action.restore)
                        {
                            e.Row.AcceptChanges();
                            e.Row.SetAdded();
                            usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.Added));
                            foreach (DataRow r in e.Row.GetChildRows("FK_GradeReport_User"))
                            {
                                r.AcceptChanges();
                                r.SetAdded();
                            }
                            gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Added));
                        }
                        else if (conflManager.action == ConflictManager.Action.skip)
                        {
                            rowReg = tblRegister.Rows.Find((int)e.Row["UserID"]);
                            tblRegister.Rows.Remove(rowReg);
                            foreach (DataRow row in e.Row.GetChildRows("FK_GradeReport_User"))
                            {
                                tblGradeReport.Rows.Remove(row);
                            }
                            tblUsers.Rows.Remove(e.Row);
                        }
                        conflManager.action = ConflictManager.Action.noAction;
                    }
                }
            }
        }
        //метод для редактирования названия предмета
        public void EditSubject(int subjectID, string NewTitle)
        {
            ClassRegisterDataSet.SubjectsRow subjToEdit = tblSubjects.FindBySubjectID(subjectID);
            if (subjToEdit != null)
            {
                tblRegister.Columns[(string)subjToEdit["Title"]].ColumnName=NewTitle;
                subjToEdit["Title"] = NewTitle;
                try
                {
                    subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.ModifiedCurrent));
                }
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.SubjectsDataTable t = new ClassRegisterDataSet.SubjectsDataTable();
                    int rowsReturned = subjectsTableAdapter.FillBySubjID(t,subjectID);
                    if (rowsReturned == 1)
                    {
                        conflManager.SubjectEditConflictOccured((int)e.Row["SubjectID"], e.Row["Title", DataRowVersion.Original].ToString(), e.Row["Title", DataRowVersion.Current].ToString(), t.Rows[0]["Title"].ToString());
                        if (conflManager.action == ConflictManager.Action.overwrite)
                        {
                            tblRegister.Columns[(string)subjToEdit["Title"]].ColumnName = NewTitle;
                            tblSubjects.Merge(t, true);
                            subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.ModifiedCurrent));
                        }
                        else if (conflManager.action == ConflictManager.Action.restore)
                        {
                            e.Row.RejectChanges();
                            tblSubjects.Merge(t, true);
                            subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.ModifiedCurrent));
                            tblRegister.Columns[NewTitle].ColumnName = (string)e.Row["Title"];
                        }
                        else if (conflManager.action == ConflictManager.Action.skip)
                        {
                            tblSubjects.Merge(t, false);
                            tblSubjects.AcceptChanges();
                            tblRegister.Columns[NewTitle].ColumnName = (string)t.Rows[0]["Title"];
                        }
                        conflManager.action = ConflictManager.Action.noAction;
                    }
                    else
                    {
                        conflManager.SubjectUpdateConflictOccured((int)e.Row["SubjectID"], (string)e.Row["Title"]);
                        if (conflManager.action == ConflictManager.Action.restore)
                        {
                            e.Row.AcceptChanges();
                            e.Row.SetAdded();
                            subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.Added));
                            foreach (DataRow r in e.Row.GetChildRows("FK_GradeReport_Subjects"))
                            {
                                r.AcceptChanges();
                                r.SetAdded();
                            }
                            gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Added));
                        }
                        else if (conflManager.action == ConflictManager.Action.skip)
                        {
                            tblRegister.Columns.Remove(NewTitle);
                            foreach (DataRow row in e.Row.GetChildRows("FK_GradeReport_Subjects"))
                            {
                                row.Delete();
                                row.AcceptChanges();
                            }
                            tblSubjects.Rows.Remove(e.Row);
                        }
                        conflManager.action = ConflictManager.Action.noAction;
                    }
                }
            }
        }
        //метод для добавления нового студента
        public void AddNewStudent(string LastName)
        {
            //проверка или было введено строковое значение.Затем добавляется новая запись 
            //в таблицу Users и в таблицу Register,после чего выполняется обновление бд
            if (LastName != "")
            {
                ClassRegisterDataSet.UsersRow r = tblUsers.NewUsersRow();
                r["LastName"] = LastName;
                r["Role"] = "student";
                tblUsers.AddUsersRow(r);
                DataRow row = tblRegister.NewRow();
                row["Last name"] = LastName;
                row["ID"] = r["UserID"];
                tblRegister.Rows.Add(row);
                row.AcceptChanges();
                usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.Added));
            }
        }
        //метод для удаления студента
        public void DeleteStudent(int ID)
        {
            //выполняется поиск студента по его ID.
            ClassRegisterDataSet.UsersRow rToDelete = tblUsers.FindByUserID(ID);
            if (rToDelete != null)
            {
                //запись о студенте помечается как удаленная
                rToDelete.Delete();
                //удаление дочерних записей-оценок по предметам данного студента
                try
                {
                    gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Deleted));
                }
                //если студент был уже удален или изменен другим пользователем,то совершается 
                //подтверждение внесенных изменений для текущей записи
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.GradeReportDataTable t = new ClassRegisterDataSet.GradeReportDataTable();
                    int rowsReturned = gradeReportTableAdapter.FillByUserIDSubjID(t, (int)e.Row["UserID", DataRowVersion.Original], (int)e.Row["SubjectID", DataRowVersion.Original]);
                    if (rowsReturned == 1)
                    {
                        tblGradeReport.Merge(t, true);
                        gradeReportTableAdapter.Update(e.Row);
                    }
                    else
                        tblGradeReport.Rows.Remove(e.Row);
                }
                //удаление студента
                try
                {
                    usersTableAdapter.Update(tblUsers.Select("", "", DataViewRowState.Deleted));
                }
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.UsersDataTable t = new ClassRegisterDataSet.UsersDataTable();
                    int rowsReturned = usersTableAdapter.FillByID(t, (int)e.Row["UserID", DataRowVersion.Original]);
                    if (rowsReturned == 1)
                    {
                        tblUsers.Merge(t, true);
                        usersTableAdapter.Update(tblUsers.Select("","", DataViewRowState.Deleted));
                    }
                    else
                        tblUsers.Rows.Remove(e.Row);
                }
                //производится удаление соотв. записи из таблицы Register
                DataRow r = tblRegister.Rows.Find(ID);
                if (r != null)
                {
                    tblRegister.Rows.Remove(r);
                }
            }
        }
        //метод для добавления нового предмета
        public void AddNewSubjects(string Title)
        {
            if (Title != "")
            {
                ClassRegisterDataSet.SubjectsRow subjToAdd = tblSubjects.NewSubjectsRow();
                subjToAdd["Title"] = Title;
                tblSubjects.AddSubjectsRow(subjToAdd);
                tblRegister.Columns.Add(Title, typeof(int));
                subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.Added));
            }
        }
        //метод для удаления предметов
        public void DeleteSubject(int SubjectID)
        {
            ClassRegisterDataSet.SubjectsRow rSubjToDelete = tblSubjects.FindBySubjectID(SubjectID);
            if (rSubjToDelete != null)
            {
                tblRegister.Columns.Remove((string)tblSubjects.FindBySubjectID(SubjectID)["Title"]);
                //предмет помечается как удаленный
                rSubjToDelete.Delete();
                try
                {
                    gradeReportTableAdapter.Update(tblGradeReport.Select("", "", DataViewRowState.Deleted));
                }
                //если предмет был уже удален другим пользователем,то совершается подтверждение внесенных
                //изменений для текущей записи
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.GradeReportDataTable t = new ClassRegisterDataSet.GradeReportDataTable();
                    int rowsReturned = gradeReportTableAdapter.FillByUserIDSubjID(t, (int)e.Row["UserID", DataRowVersion.Original], (int)e.Row["SubjectID", DataRowVersion.Original]);
                    if (rowsReturned == 1)
                    {
                        tblGradeReport.Merge(t, true);
                        gradeReportTableAdapter.Update(e.Row);
                    }
                    else
                        tblGradeReport.Rows.Remove(e.Row);
                }
                try
                {
                    subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.Deleted));
                }
                catch (DBConcurrencyException e)
                {
                    ClassRegisterDataSet.SubjectsDataTable t = new ClassRegisterDataSet.SubjectsDataTable();
                    int rowsReturned = subjectsTableAdapter.FillBySubjID(t, (int)e.Row["SubjectID", DataRowVersion.Original]);
                    if (rowsReturned == 1)
                    {
                        tblSubjects.Merge(t, true);
                        subjectsTableAdapter.Update(tblSubjects.Select("", "", DataViewRowState.Deleted));
                    }
                    else
                        tblSubjects.Rows.Remove(e.Row);
                }
            }
        }
        //метод для нахождения названия предмета по его ID
        private string GetTitleByID(int subjectID)
        {
            string Title = "";
            foreach (ClassRegisterDataSet.SubjectsRow rowSubject in tblSubjects)
            {
                if ((int)rowSubject["SubjectID"] == subjectID)
                    Title = (string)rowSubject["Title"];
            }
            return Title;
        }
        //метод для нахождения ID предмета по его названию
        private int GetIDByTitle(string Title)
        {
            int ID=-1;
            foreach(ClassRegisterDataSet.SubjectsRow rowSubject in tblSubjects )
            {
                if ((string)rowSubject["Title"] == Title)
                    ID = (int)rowSubject["SubjectID"];
            }
            return ID;
        }
        private string GetPasswordHash(string Password)
        {
            string strHash;
            MD5 passwordHash = new MD5CryptoServiceProvider();
            passwordHash.ComputeHash(Encoding.ASCII.GetBytes(Password));
            strHash = Convert.ToBase64String(passwordHash.Hash);
            return strHash;
        }
        public bool CheckUser(string Login, string Password)
        {
            bool accessAllowed=false;
            string HashPwd = GetPasswordHash(Password);
            int rowsReturned = (int)usersTableAdapter.CheckUser(Login, HashPwd);
            if (rowsReturned == 1)
                accessAllowed = true;
            return accessAllowed;
        }
    }


    public class ConflictManager
    {
        public ConflictManager()
        {
            action = Action.noAction;
        }
        public enum Action
        {
            overwrite,
            restore,
            skip,
            noAction
        }
        public event EventHandler<UserEditEventArgs> UserEditConflict;
        public event EventHandler<UserUpdateEventArgs> UserUpdateConflict;
        public event EventHandler<GradeReportEventArgs> GradeReportUpdateConflict;
        public event EventHandler<SubjectEditEventArgs> SubjectEditConflict;
        public event EventHandler<SubjectUpdateEventArgs> SubjectUpdateConflict;
        public Action action;
        private void OnUserUpdateConflict(UserUpdateEventArgs e)
        {
            EventHandler<UserUpdateEventArgs> temp = UserUpdateConflict;
            if (temp != null) temp(this, e);
        }
        private void OnSubjectEditConflict(SubjectEditEventArgs e)
        {
            EventHandler<SubjectEditEventArgs> temp = SubjectEditConflict;
            if (temp != null) temp(this, e);
        }
        private void OnUserEditConflict(UserEditEventArgs e)
        {
            EventHandler<UserEditEventArgs> temp = UserEditConflict;
            if (temp != null) temp(this, e);
        }
        private void OnGradeReportUpdateConflict(GradeReportEventArgs e)
        {
            EventHandler<GradeReportEventArgs> temp = GradeReportUpdateConflict;
            if (temp != null) temp(this, e);
        }
        private void OnSubjectUpdateConflict(SubjectUpdateEventArgs e)
        {
            EventHandler<SubjectUpdateEventArgs> temp = SubjectUpdateConflict;
            if (temp != null) temp(this, e);
        }
        public void SubjectUpdateConflictOccured(int SubjectID,string Title)
        {
            SubjectUpdateEventArgs e = new SubjectUpdateEventArgs(SubjectID, Title);
            OnSubjectUpdateConflict(e);
        }
        public void UserEditConflictOccured(int ID, string OrigLName, string ModifLName, string CurrLNameInDB)
        {
            UserEditEventArgs e = new UserEditEventArgs(ID, OrigLName, ModifLName, CurrLNameInDB);
            OnUserEditConflict(e);
        }
        public void UserUpdateConflictOccured(int StudentID, string LastName)
        {
            UserUpdateEventArgs e = new UserUpdateEventArgs(StudentID, LastName);
            OnUserUpdateConflict(e);
        }
        public void SubjectEditConflictOccured(int SubjectID, string OrigTitle,string EnteredTitle,string TitleInDB)
        {
            SubjectEditEventArgs e = new SubjectEditEventArgs(SubjectID, OrigTitle, EnteredTitle, TitleInDB);
            OnSubjectEditConflict(e);
        }
        public void GrReportUpdateConflict(DataTable ConflictRates,DataTable UsersDeleted,DataTable SubjectsDeleted)
        {
            GradeReportEventArgs e = new GradeReportEventArgs(ConflictRates,UsersDeleted,SubjectsDeleted);
            OnGradeReportUpdateConflict(e);
        }
    }
    public class UserEditEventArgs : EventArgs
    {
        private readonly string origLName, modifLName, currLName;
        private readonly int studentID;
        public UserEditEventArgs(int ID, string OrigLName, string ModifLName, string CurrLName)
        {
            studentID = ID;
            origLName = OrigLName;
            modifLName = ModifLName;
            currLName = CurrLName;
        }
        public int StudentID { get { return studentID; } }
        public string OrigLName { get { return origLName; } }
        public string ModifLName { get { return modifLName; } }
        public string CurrLName { get { return currLName; } }
    }
    public class UserUpdateEventArgs : EventArgs
    {
        readonly string lastName;
        readonly int studentID;
        public UserUpdateEventArgs(int ID, string LastName)
        {
            studentID = ID;
            lastName = LastName;
        }
        public string LastName { get { return lastName; } }
        public int StudentID { get { return studentID; } }
    }
    public class GradeReportEventArgs : EventArgs
    {
        readonly DataTable concurentRates;
        readonly DataTable usersDeleted;
        readonly DataTable subjectsDeleted;
        public GradeReportEventArgs(DataTable tConcurRates, DataTable UsersDeleted, DataTable SubjectsDeleted)
        {
            concurentRates = tConcurRates;
            usersDeleted = UsersDeleted;
            subjectsDeleted = SubjectsDeleted;
        }
        public DataTable ConcurentRates
        { get { return concurentRates; } }
        public DataTable UsersDeleted
        {
            get { return usersDeleted; }
        }
        public DataTable SubjectsDeleted
        {
            get { return subjectsDeleted; }
        }
    }
    public class SubjectEditEventArgs : EventArgs
    { 
        private readonly string origTitle, modifTitle, currTitle;
        private readonly int subjectID;
        public SubjectEditEventArgs(int SubjectID, string OrigTitle, string ModifTitle, string CurrTitle)
        {
            subjectID = SubjectID;
            origTitle = OrigTitle;
            modifTitle = ModifTitle;
            currTitle = CurrTitle;
        }
        public int SubjectID { get { return subjectID; } }
        public string OriginalTitle { get { return origTitle; } }
        public string EnteredTitle { get { return modifTitle; } }
        public string TitleInDB { get { return currTitle; } }
    }
    public class SubjectUpdateEventArgs : EventArgs
    {
        private readonly string title;
        private readonly int subjectId;
        public SubjectUpdateEventArgs(int SubjectID, string Title)
        {
            subjectId = SubjectID;
            title = Title;
        }
        public int SubjectID
        { get { return subjectId; } }
        public string Title
        { get { return title; } }
    }
}
