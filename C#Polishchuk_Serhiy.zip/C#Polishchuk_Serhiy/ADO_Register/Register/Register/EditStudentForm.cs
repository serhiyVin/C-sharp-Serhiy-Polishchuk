﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class EditStudentForm : Form
    {
        public EditStudentForm()
        {
            InitializeComponent();
        }
        public EditStudentForm(string strID, string strLastName)
        { 
            InitializeComponent();
            this.txtID.Text = strID;
            this.txtLastName.Text = strLastName;
        }

        public string EditedName
        { get { return txtLastName.Text; } }

        private void txtLastName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnOk.PerformClick();
            }
        }

    }
}
