﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Class_Register
{
    public partial class UserEditConflictForm : Form
    {
        public UserEditConflictForm()
        {
            InitializeComponent();
        }
        public UserEditConflictForm(int ID, string nameOrig, string nameEntered, string nameCurr)
        {
            InitializeComponent();
            lblID.Text += ID.ToString();
            txtNameOrig.Text = nameOrig;
            txtNameEntered.Text = nameEntered;
            txtNameCurrent.Text = nameCurr;
        }

    }
}
