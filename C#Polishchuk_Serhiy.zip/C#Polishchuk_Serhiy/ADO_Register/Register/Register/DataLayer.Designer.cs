﻿namespace Class_Register
{
    partial class DataLayer
    {
        /// <summary>
        /// Required designer variable. 
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cn = new System.Data.SqlClient.SqlConnection();
            this.sqlCmd = new System.Data.SqlClient.SqlCommand();
            this.classRegDs = new Class_Register.ClassRegisterDataSet();
            this.usersTableAdapter = new Class_Register.ClassRegisterDataSetTableAdapters.UsersTableAdapter();
            this.gradeReportTableAdapter = new Class_Register.ClassRegisterDataSetTableAdapters.GradeReportTableAdapter();
            this.subjectsTableAdapter = new Class_Register.ClassRegisterDataSetTableAdapters.SubjectsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.classRegDs)).BeginInit();
            // 
            // cn
            // 
            //this.cn.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Register.mdf;Integrated" +
            //    " Security=True;User Instance=True";
            this.cn.ConnectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\Register.mdf;Integra" +
            "ted Security=True;User Instance=false";
            this.cn.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlCmd
            // 
            this.sqlCmd.Connection = this.cn;
            // 
            // classRegDs
            // 
            this.classRegDs.DataSetName = "ClassRegisterDataSet";
            this.classRegDs.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // gradeReportTableAdapter
            // 
            this.gradeReportTableAdapter.ClearBeforeFill = true;
            // 
            // subjectsTableAdapter
            // 
            this.subjectsTableAdapter.ClearBeforeFill = true;
            ((System.ComponentModel.ISupportInitialize)(this.classRegDs)).EndInit();

        }

        #endregion

        private System.Data.SqlClient.SqlConnection cn;
        private System.Data.SqlClient.SqlCommand sqlCmd;
        private ClassRegisterDataSet classRegDs;
        private Class_Register.ClassRegisterDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
        private Class_Register.ClassRegisterDataSetTableAdapters.GradeReportTableAdapter gradeReportTableAdapter;
        private Class_Register.ClassRegisterDataSetTableAdapters.SubjectsTableAdapter subjectsTableAdapter;

    }
}
