﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Text;

namespace Class_Register
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            DataLayer dLayer=new DataLayer ();
            AuthentFrm frm = new AuthentFrm();
            if (frm.ShowDialog() == DialogResult.OK)
            { 
                if (dLayer.CheckUser(frm.Login, frm.Password))
                    Application.Run(new Mainframe());
            }
        }
    }
}
