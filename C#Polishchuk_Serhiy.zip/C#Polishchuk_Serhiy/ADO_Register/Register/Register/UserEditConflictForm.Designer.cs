﻿namespace Class_Register
{
    partial class UserEditConflictForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnOverrite = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtNameOrig = new System.Windows.Forms.TextBox();
            this.txtNameEntered = new System.Windows.Forms.TextBox();
            this.txtNameCurrent = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOverrite
            // 
            this.btnOverrite.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOverrite.Location = new System.Drawing.Point(31, 219);
            this.btnOverrite.Name = "btnOverrite";
            this.btnOverrite.Size = new System.Drawing.Size(75, 23);
            this.btnOverrite.TabIndex = 0;
            this.btnOverrite.Text = "Overwrite";
            this.toolTip.SetToolTip(this.btnOverrite, "Overwrite cnanges made by another user");
            this.btnOverrite.UseVisualStyleBackColor = true;
            // 
            // btnRestore
            // 
            this.btnRestore.DialogResult = System.Windows.Forms.DialogResult.Retry;
            this.btnRestore.Location = new System.Drawing.Point(155, 219);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(75, 23);
            this.btnRestore.TabIndex = 1;
            this.btnRestore.Text = "Restore";
            this.toolTip.SetToolTip(this.btnRestore, "Restore original name");
            this.btnRestore.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Ignore;
            this.btnCancel.Location = new System.Drawing.Point(282, 219);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Skip";
            this.toolTip.SetToolTip(this.btnCancel, "Save current in database");
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // txtNameOrig
            // 
            this.txtNameOrig.Location = new System.Drawing.Point(108, 22);
            this.txtNameOrig.Name = "txtNameOrig";
            this.txtNameOrig.ReadOnly = true;
            this.txtNameOrig.Size = new System.Drawing.Size(182, 20);
            this.txtNameOrig.TabIndex = 3;
            this.txtNameOrig.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNameEntered
            // 
            this.txtNameEntered.Location = new System.Drawing.Point(108, 53);
            this.txtNameEntered.Name = "txtNameEntered";
            this.txtNameEntered.ReadOnly = true;
            this.txtNameEntered.Size = new System.Drawing.Size(182, 20);
            this.txtNameEntered.TabIndex = 4;
            this.txtNameEntered.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNameCurrent
            // 
            this.txtNameCurrent.Location = new System.Drawing.Point(108, 82);
            this.txtNameCurrent.Name = "txtNameCurrent";
            this.txtNameCurrent.ReadOnly = true;
            this.txtNameCurrent.Size = new System.Drawing.Size(182, 20);
            this.txtNameCurrent.TabIndex = 5;
            this.txtNameCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Original";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Entered";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Current in DB";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtNameCurrent);
            this.groupBox1.Controls.Add(this.txtNameEntered);
            this.groupBox1.Controls.Add(this.txtNameOrig);
            this.groupBox1.Location = new System.Drawing.Point(31, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 124);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Last name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(340, 38);
            this.label4.TabIndex = 10;
            this.label4.Text = "The last name of this student has already been modified\r\n by another user";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblID.Location = new System.Drawing.Point(33, 57);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(74, 15);
            this.lblID.TabIndex = 11;
            this.lblID.Text = "Student ID : ";
            // 
            // UserEditConflictForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(377, 265);
            this.ControlBox = false;
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRestore);
            this.Controls.Add(this.btnOverrite);
            this.Name = "UserEditConflictForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Conflict action";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOverrite;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtNameOrig;
        private System.Windows.Forms.TextBox txtNameEntered;
        private System.Windows.Forms.TextBox txtNameCurrent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblID;
    }
}