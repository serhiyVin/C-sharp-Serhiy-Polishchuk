﻿namespace Class_Register
{
    partial class ReportsErr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOverrite = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOverrite
            // 
            this.btnOverrite.Location = new System.Drawing.Point(54, 168);
            this.btnOverrite.Name = "btnOverrite";
            this.btnOverrite.Size = new System.Drawing.Size(109, 23);
            this.btnOverrite.TabIndex = 0;
            this.btnOverrite.Text = "Overrite";
            this.btnOverrite.UseVisualStyleBackColor = true;
            // 
            // btnRestore
            // 
            this.btnRestore.Location = new System.Drawing.Point(202, 168);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(109, 23);
            this.btnRestore.TabIndex = 1;
            this.btnRestore.Text = "Restore original";
            this.btnRestore.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(346, 168);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Cancel update";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // ReportsErr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 213);
            this.ControlBox = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnRestore);
            this.Controls.Add(this.btnOverrite);
            this.Name = "ReportsErr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "UsersNotUpdated";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOverrite; 
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Button button3;
    }
}