namespace CreditClient
{
    partial class ClientFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label creditIDLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnAddCredit = new System.Windows.Forms.Button();
            this.btnSaveDb = new System.Windows.Forms.Button();
            this.btnDtrsTotal = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAddPayment = new System.Windows.Forms.Button();
            this.txtPayAmount = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.paymentsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.creditsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.debtorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet = new CreditClient.DataBase01DataSet();
            this.creditIDTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.lblAmount = new System.Windows.Forms.Label();
            this.groupCredits = new System.Windows.Forms.GroupBox();
            this.creditsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblDebtName = new System.Windows.Forms.Label();
            this.txtDebtName = new System.Windows.Forms.TextBox();
            this.txtCredAmount = new System.Windows.Forms.TextBox();
            this.lblCredAmount = new System.Windows.Forms.Label();
            this.groupDebtors = new System.Windows.Forms.GroupBox();
            this.lblEnterName = new System.Windows.Forms.Label();
            this.debtorsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtNewDebtor = new System.Windows.Forms.TextBox();
            this.btnNewDtr = new System.Windows.Forms.Button();
            this.lblDebtTotal = new System.Windows.Forms.Label();
            this.lblCnStatus = new System.Windows.Forms.Label();
            this.debtorsTableAdapter = new CreditClient.DataBase01DataSetTableAdapters.DebtorsTableAdapter();
            this.creditsTableAdapter = new CreditClient.DataBase01DataSetTableAdapters.CreditsTableAdapter();
            this.paymentsTableAdapter = new CreditClient.DataBase01DataSetTableAdapters.PaymentsTableAdapter();
            nameLabel = new System.Windows.Forms.Label();
            creditIDLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.creditsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.debtorsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).BeginInit();
            this.groupCredits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creditsDataGridView)).BeginInit();
            this.groupDebtors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.debtorsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(16, 187);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(38, 13);
            nameLabel.TabIndex = 12;
            nameLabel.Text = "Name:";
            // 
            // creditIDLabel
            // 
            creditIDLabel.AutoSize = true;
            creditIDLabel.Location = new System.Drawing.Point(16, 213);
            creditIDLabel.Name = "creditIDLabel";
            creditIDLabel.Size = new System.Drawing.Size(51, 13);
            creditIDLabel.TabIndex = 13;
            creditIDLabel.Text = "Credit ID:";
            // 
            // btnAddCredit
            // 
            this.btnAddCredit.Location = new System.Drawing.Point(247, 233);
            this.btnAddCredit.Name = "btnAddCredit";
            this.btnAddCredit.Size = new System.Drawing.Size(87, 23);
            this.btnAddCredit.TabIndex = 4;
            this.btnAddCredit.Text = "Add new credit";
            this.btnAddCredit.UseVisualStyleBackColor = true;
            this.btnAddCredit.Click += new System.EventHandler(this.btnAddCredit_Click);
            // 
            // btnSaveDb
            // 
            this.btnSaveDb.Location = new System.Drawing.Point(786, 314);
            this.btnSaveDb.Name = "btnSaveDb";
            this.btnSaveDb.Size = new System.Drawing.Size(105, 23);
            this.btnSaveDb.TabIndex = 5;
            this.btnSaveDb.Text = "Save DB to disc";
            this.btnSaveDb.UseVisualStyleBackColor = true;
            this.btnSaveDb.Click += new System.EventHandler(this.btnSaveDb_Click);
            // 
            // btnDtrsTotal
            // 
            this.btnDtrsTotal.Location = new System.Drawing.Point(7, 233);
            this.btnDtrsTotal.Name = "btnDtrsTotal";
            this.btnDtrsTotal.Size = new System.Drawing.Size(92, 23);
            this.btnDtrsTotal.TabIndex = 6;
            this.btnDtrsTotal.Text = "Total of debtors";
            this.btnDtrsTotal.UseVisualStyleBackColor = true;
            this.btnDtrsTotal.Click += new System.EventHandler(this.btnDtrsTotal_Click);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "PaymentID";
            this.dataGridViewTextBoxColumn7.HeaderText = "PaymentID";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CreditID";
            this.dataGridViewTextBoxColumn8.HeaderText = "CreditID";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn9.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Data";
            this.dataGridViewTextBoxColumn10.HeaderText = "Data";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // btnAddPayment
            // 
            this.btnAddPayment.Location = new System.Drawing.Point(228, 238);
            this.btnAddPayment.Name = "btnAddPayment";
            this.btnAddPayment.Size = new System.Drawing.Size(101, 23);
            this.btnAddPayment.TabIndex = 3;
            this.btnAddPayment.Text = "Add new payment";
            this.btnAddPayment.UseVisualStyleBackColor = true;
            this.btnAddPayment.Click += new System.EventHandler(this.btnAddPayment_Click);
            // 
            // txtPayAmount
            // 
            this.txtPayAmount.Location = new System.Drawing.Point(71, 240);
            this.txtPayAmount.Name = "txtPayAmount";
            this.txtPayAmount.Size = new System.Drawing.Size(100, 20);
            this.txtPayAmount.TabIndex = 9;
            this.txtPayAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPayAmount_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.paymentsDataGridView);
            this.groupBox1.Controls.Add(creditIDLabel);
            this.groupBox1.Controls.Add(this.creditIDTextBox);
            this.groupBox1.Controls.Add(nameLabel);
            this.groupBox1.Controls.Add(this.nameTextBox);
            this.groupBox1.Controls.Add(this.lblAmount);
            this.groupBox1.Controls.Add(this.txtPayAmount);
            this.groupBox1.Controls.Add(this.btnAddPayment);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(558, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(362, 275);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payments";
            // 
            // paymentsDataGridView
            // 
            this.paymentsDataGridView.AllowUserToAddRows = false;
            this.paymentsDataGridView.AllowUserToDeleteRows = false;
            this.paymentsDataGridView.AutoGenerateColumns = false;
            this.paymentsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.paymentsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.paymentsDataGridView.DataSource = this.paymentsBindingSource;
            this.paymentsDataGridView.Location = new System.Drawing.Point(6, 19);
            this.paymentsDataGridView.Name = "paymentsDataGridView";
            this.paymentsDataGridView.ReadOnly = true;
            this.paymentsDataGridView.Size = new System.Drawing.Size(350, 156);
            this.paymentsDataGridView.TabIndex = 14;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "PaymentID";
            this.dataGridViewTextBoxColumn11.HeaderText = "PaymentID";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "CreditID";
            this.dataGridViewTextBoxColumn12.HeaderText = "CreditID";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Amount";
            dataGridViewCellStyle5.Format = "C2";
            dataGridViewCellStyle5.NullValue = null;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn13.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Date";
            dataGridViewCellStyle6.Format = "d";
            dataGridViewCellStyle6.NullValue = null;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn14.HeaderText = "Date";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // paymentsBindingSource
            // 
            this.paymentsBindingSource.DataMember = "FK_Payments_Credits";
            this.paymentsBindingSource.DataSource = this.creditsBindingSource;
            // 
            // creditsBindingSource
            // 
            this.creditsBindingSource.DataMember = "FK_Credits_Debtors";
            this.creditsBindingSource.DataSource = this.debtorsBindingSource;
            // 
            // debtorsBindingSource
            // 
            this.debtorsBindingSource.DataMember = "Debtors";
            this.debtorsBindingSource.DataSource = this.dataSet;
            // 
            // dataSet
            // 
            this.dataSet.DataSetName = "DataBase01DataSet";
            this.dataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // creditIDTextBox
            // 
            this.creditIDTextBox.Location = new System.Drawing.Point(71, 212);
            this.creditIDTextBox.Name = "creditIDTextBox";
            this.creditIDTextBox.ReadOnly = true;
            this.creditIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.creditIDTextBox.TabIndex = 14;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.debtorsBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(71, 184);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.ReadOnly = true;
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 13;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(16, 245);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(49, 13);
            this.lblAmount.TabIndex = 12;
            this.lblAmount.Text = "Amount :";
            // 
            // groupCredits
            // 
            this.groupCredits.Controls.Add(this.creditsDataGridView);
            this.groupCredits.Controls.Add(this.lblDebtName);
            this.groupCredits.Controls.Add(this.txtDebtName);
            this.groupCredits.Controls.Add(this.txtCredAmount);
            this.groupCredits.Controls.Add(this.lblCredAmount);
            this.groupCredits.Controls.Add(this.btnAddCredit);
            this.groupCredits.Location = new System.Drawing.Point(212, 21);
            this.groupCredits.Name = "groupCredits";
            this.groupCredits.Size = new System.Drawing.Size(340, 275);
            this.groupCredits.TabIndex = 13;
            this.groupCredits.TabStop = false;
            this.groupCredits.Text = "Credits";
            // 
            // creditsDataGridView
            // 
            this.creditsDataGridView.AllowUserToAddRows = false;
            this.creditsDataGridView.AllowUserToDeleteRows = false;
            this.creditsDataGridView.AutoGenerateColumns = false;
            this.creditsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.creditsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.creditsDataGridView.DataSource = this.creditsBindingSource;
            this.creditsDataGridView.Location = new System.Drawing.Point(10, 19);
            this.creditsDataGridView.Name = "creditsDataGridView";
            this.creditsDataGridView.ReadOnly = true;
            this.creditsDataGridView.Size = new System.Drawing.Size(326, 156);
            this.creditsDataGridView.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "CreditID";
            this.dataGridViewTextBoxColumn3.HeaderText = "CreditID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DebtorID";
            this.dataGridViewTextBoxColumn4.HeaderText = "DebtorID";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Amount";
            dataGridViewCellStyle7.Format = "C2";
            dataGridViewCellStyle7.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn5.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Balance";
            dataGridViewCellStyle8.Format = "C2";
            dataGridViewCellStyle8.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn6.HeaderText = "Balance";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // lblDebtName
            // 
            this.lblDebtName.AutoSize = true;
            this.lblDebtName.Location = new System.Drawing.Point(11, 197);
            this.lblDebtName.Name = "lblDebtName";
            this.lblDebtName.Size = new System.Drawing.Size(76, 13);
            this.lblDebtName.TabIndex = 17;
            this.lblDebtName.Text = "New credit to :";
            // 
            // txtDebtName
            // 
            this.txtDebtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.debtorsBindingSource, "Name", true));
            this.txtDebtName.Location = new System.Drawing.Point(108, 195);
            this.txtDebtName.Name = "txtDebtName";
            this.txtDebtName.ReadOnly = true;
            this.txtDebtName.Size = new System.Drawing.Size(85, 20);
            this.txtDebtName.TabIndex = 16;
            // 
            // txtCredAmount
            // 
            this.txtCredAmount.Location = new System.Drawing.Point(108, 233);
            this.txtCredAmount.Name = "txtCredAmount";
            this.txtCredAmount.Size = new System.Drawing.Size(85, 20);
            this.txtCredAmount.TabIndex = 15;
            this.txtCredAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCredAmount_KeyPress);
            // 
            // lblCredAmount
            // 
            this.lblCredAmount.AutoSize = true;
            this.lblCredAmount.Location = new System.Drawing.Point(11, 238);
            this.lblCredAmount.Name = "lblCredAmount";
            this.lblCredAmount.Size = new System.Drawing.Size(90, 13);
            this.lblCredAmount.TabIndex = 14;
            this.lblCredAmount.Text = "Amount of credit :";
            // 
            // groupDebtors
            // 
            this.groupDebtors.AutoSize = true;
            this.groupDebtors.Controls.Add(this.lblEnterName);
            this.groupDebtors.Controls.Add(this.debtorsDataGridView);
            this.groupDebtors.Controls.Add(this.txtNewDebtor);
            this.groupDebtors.Controls.Add(this.btnNewDtr);
            this.groupDebtors.Controls.Add(this.btnDtrsTotal);
            this.groupDebtors.Controls.Add(this.lblDebtTotal);
            this.groupDebtors.Location = new System.Drawing.Point(7, 21);
            this.groupDebtors.Name = "groupDebtors";
            this.groupDebtors.Size = new System.Drawing.Size(199, 275);
            this.groupDebtors.TabIndex = 14;
            this.groupDebtors.TabStop = false;
            this.groupDebtors.Text = "Debtors";
            // 
            // lblEnterName
            // 
            this.lblEnterName.AutoSize = true;
            this.lblEnterName.Location = new System.Drawing.Point(4, 179);
            this.lblEnterName.Name = "lblEnterName";
            this.lblEnterName.Size = new System.Drawing.Size(76, 13);
            this.lblEnterName.TabIndex = 15;
            this.lblEnterName.Text = "Enter a name :";
            // 
            // debtorsDataGridView
            // 
            this.debtorsDataGridView.AllowUserToAddRows = false;
            this.debtorsDataGridView.AllowUserToDeleteRows = false;
            this.debtorsDataGridView.AutoGenerateColumns = false;
            this.debtorsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.debtorsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.debtorsDataGridView.DataSource = this.debtorsBindingSource;
            this.debtorsDataGridView.Location = new System.Drawing.Point(7, 19);
            this.debtorsDataGridView.Name = "debtorsDataGridView";
            this.debtorsDataGridView.ReadOnly = true;
            this.debtorsDataGridView.RowHeadersVisible = false;
            this.debtorsDataGridView.Size = new System.Drawing.Size(181, 156);
            this.debtorsDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DebtorID";
            this.dataGridViewTextBoxColumn1.HeaderText = "DebtorID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // txtNewDebtor
            // 
            this.txtNewDebtor.Location = new System.Drawing.Point(7, 195);
            this.txtNewDebtor.Name = "txtNewDebtor";
            this.txtNewDebtor.Size = new System.Drawing.Size(73, 20);
            this.txtNewDebtor.TabIndex = 15;
            // 
            // btnNewDtr
            // 
            this.btnNewDtr.Location = new System.Drawing.Point(97, 195);
            this.btnNewDtr.Name = "btnNewDtr";
            this.btnNewDtr.Size = new System.Drawing.Size(92, 23);
            this.btnNewDtr.TabIndex = 14;
            this.btnNewDtr.Text = "Add debtor";
            this.btnNewDtr.UseVisualStyleBackColor = true;
            this.btnNewDtr.Click += new System.EventHandler(this.btnNewDtr_Click);
            // 
            // lblDebtTotal
            // 
            this.lblDebtTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDebtTotal.Location = new System.Drawing.Point(146, 233);
            this.lblDebtTotal.Name = "lblDebtTotal";
            this.lblDebtTotal.Size = new System.Drawing.Size(42, 23);
            this.lblDebtTotal.TabIndex = 13;
            this.lblDebtTotal.Text = "   ";
            this.lblDebtTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCnStatus
            // 
            this.lblCnStatus.Location = new System.Drawing.Point(12, 324);
            this.lblCnStatus.Name = "lblCnStatus";
            this.lblCnStatus.Size = new System.Drawing.Size(413, 16);
            this.lblCnStatus.TabIndex = 15;
            this.lblCnStatus.Text = "  ";
            // 
            // debtorsTableAdapter
            // 
            this.debtorsTableAdapter.ClearBeforeFill = true;
            // 
            // creditsTableAdapter
            // 
            this.creditsTableAdapter.ClearBeforeFill = true;
            // 
            // paymentsTableAdapter
            // 
            this.paymentsTableAdapter.ClearBeforeFill = true;
            // 
            // ClientFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(946, 335);
            this.Controls.Add(this.lblCnStatus);
            this.Controls.Add(this.groupDebtors);
            this.Controls.Add(this.groupCredits);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSaveDb);
            this.MaximizeBox = false;
            this.Name = "ClientFrm";
            this.Text = "Client Credit";
            this.Load += new System.EventHandler(this.ClientFrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.creditsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.debtorsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).EndInit();
            this.groupCredits.ResumeLayout(false);
            this.groupCredits.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creditsDataGridView)).EndInit();
            this.groupDebtors.ResumeLayout(false);
            this.groupDebtors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.debtorsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Button btnAddCredit;
        private System.Windows.Forms.Button btnSaveDb;
        private System.Windows.Forms.Button btnDtrsTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.Button btnAddPayment;
        private System.Windows.Forms.TextBox txtPayAmount;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.GroupBox groupCredits;
        private System.Windows.Forms.GroupBox groupDebtors;
        private System.Windows.Forms.Label lblCredAmount;
        private System.Windows.Forms.TextBox txtCredAmount;
        private System.Windows.Forms.Label lblDebtTotal;
        private System.Windows.Forms.TextBox txtDebtName;
        private System.Windows.Forms.Label lblDebtName;
        private System.Windows.Forms.TextBox txtNewDebtor;
        private System.Windows.Forms.Button btnNewDtr;
        private DataBase01DataSet dataSet;
        private System.Windows.Forms.BindingSource debtorsBindingSource;
        private CreditClient.DataBase01DataSetTableAdapters.DebtorsTableAdapter debtorsTableAdapter;
        private System.Windows.Forms.DataGridView debtorsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Label lblEnterName;
        private System.Windows.Forms.TextBox creditIDTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label lblCnStatus;
        private System.Windows.Forms.BindingSource creditsBindingSource;
        private CreditClient.DataBase01DataSetTableAdapters.CreditsTableAdapter creditsTableAdapter;
        private System.Windows.Forms.DataGridView creditsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingSource paymentsBindingSource;
        private CreditClient.DataBase01DataSetTableAdapters.PaymentsTableAdapter paymentsTableAdapter;
        private System.Windows.Forms.DataGridView paymentsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
    }
}

