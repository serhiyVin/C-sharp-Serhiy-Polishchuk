/*
** All Rights Reserved.
*/
SET NOCOUNT ON
GO

USE master
GO
if exists (select * from sysdatabases where name='DataBase01')
		drop database DataBase01
go

DECLARE @device_directory NVARCHAR(520)
SELECT @device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1)
FROM master.dbo.sysaltfiles WHERE dbid = 1 AND fileid = 1

EXECUTE (N'CREATE DATABASE DataBase01
  ON PRIMARY (NAME = N''DataBase01'', FILENAME = N''' + @device_directory + N'DataBase01.mdf'')
  LOG ON (NAME = N''DataBase01_log'',  FILENAME = N''' + @device_directory + N'DataBase01.ldf'')')
go

--exec sp_dboption 'DataBase01','trunc. log on chkpt.','true'
--exec sp_dboption 'DataBase01','select into/bulkcopy','true'
GO

set quoted_identifier on
GO

/* Set DATEFORMAT so that the date strings are interpreted correctly regardless of
   the default DATEFORMAT on the server.
*/
SET DATEFORMAT dmy
GO
use "DataBase01"
go

CREATE TABLE "Debtors" (
	"DebtorID" "int" IDENTITY (1, 1) NOT NULL ,
	"Name" nvarchar (20) NOT NULL ,
	CONSTRAINT "PK_Debtors" PRIMARY KEY  CLUSTERED 
	(
		"DebtorID"
	)
)
GO
CREATE TABLE "Credits" (
	"CreditID" "int" IDENTITY (1, 1) NOT NULL ,
	"DebtorID" "int"  NOT NULL ,
	"Amount" "money"  NULL ,
	"Balance" "money"  NULL ,
	CONSTRAINT "PK_Credits" PRIMARY KEY  CLUSTERED 
	(
		"CreditID"
	),
	CONSTRAINT "FK_Credits_Debtors" FOREIGN KEY 
	(
		"DebtorID"
	) REFERENCES "dbo"."Debtors" (
		"DebtorID"
	)
)
GO
CREATE TABLE "Payments" (
	"PaymentID" "int" IDENTITY (1, 1) NOT NULL ,
	"CreditID" "int"  NOT NULL ,
	"Amount" "money"  NULL ,
	"Date" "datetime"  NULL ,
	CONSTRAINT "PK_Payments" PRIMARY KEY  CLUSTERED 
	(
		"PaymentID"
	),
	CONSTRAINT "FK_Payments_Credits" FOREIGN KEY 
	(
		"CreditID"
	) REFERENCES "dbo"."Credits" (
		"CreditID"
	)
)
GO
set quoted_identifier on
go
set identity_insert "Debtors" on
go
ALTER TABLE "Debtors" NOCHECK CONSTRAINT ALL
go
INSERT "Debtors"("DebtorID","Name") VALUES(1,'Mike')
INSERT "Debtors"("DebtorID","Name") VALUES(2,'John')
INSERT "Debtors"("DebtorID","Name") VALUES(3,'Maria')
INSERT "Debtors"("DebtorID","Name") VALUES(4,'Steve')
INSERT "Debtors"("DebtorID","Name") VALUES(5,'David')
INSERT "Debtors"("DebtorID","Name") VALUES(6,'Lucy')
INSERT "Debtors"("DebtorID","Name") VALUES(7,'Kate')
INSERT "Debtors"("DebtorID","Name") VALUES(8,'Jurgen')
go
set identity_insert "Debtors" off
go
set quoted_identifier on
go
set identity_insert "Credits" on
go
ALTER TABLE "Credits" NOCHECK CONSTRAINT ALL
go
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(1,1,3100,2200)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(2,2,2800,2000)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(3,3,4200,3400)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(4,1,1500,1050)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(5,4,5000,3500)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(6,3,2300,1350)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(7,5,3700,3000)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(8,6,1600,1120)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(9,6,1900,1500)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(10,7,2200,1750)
INSERT "Credits"("CreditID","DebtorID","Amount","Balance") VALUES(11,8,3700,3000)
go
set identity_insert "Credits" off
go
set quoted_identifier on
go
set identity_insert "Payments" on
go
ALTER TABLE "Payments" NOCHECK CONSTRAINT ALL
go
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(1,1,250,'15/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(2,2,200,'15/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(3,3,250,'16/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(4,4,100,'17/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(5,5,400,'18/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(6,6,300,'18/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(7,7,200,'19/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(8,8,220,'22/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(9,9,150,'23/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(10,10,200,'23/1/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(11,11,350,'24/1/2016')
go
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(12,1,350,'13/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(13,2,300,'14/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(14,3,250,'14/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(15,4,200,'16/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(16,5,550,'17/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(17,6,300,'18/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(18,7,250,'18/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(19,8,260,'21/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(20,9,250,'22/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(21,10,250,'22/2/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(22,11,350,'23/2/2016')
go
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(23,1,300,'13/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(24,2,300,'14/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(25,3,300,'15/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(26,4,150,'17/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(27,5,550,'18/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(28,6,350,'19/3/2016')
INSERT "Payments"("PaymentID","CreditID","Amount","Date") VALUES(29,7,250,'19/3/2016')
go
set identity_insert "Payments" off
go