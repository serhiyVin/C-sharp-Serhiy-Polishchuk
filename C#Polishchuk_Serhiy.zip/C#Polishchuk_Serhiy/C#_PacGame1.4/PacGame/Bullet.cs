﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Threading;


namespace PacGame
{
    public class Bullet
    {
        System.Media.SoundPlayer pl = new System.Media.SoundPlayer(@"SoundEffects\MonsterEaten.wav");
        int step;
        GameBoard gameBoard;
        Rectangle location;
        List<Character> targets;
        CharacterDirection direction;
        public Rectangle Location
        {
            get { return location; } 
        }
        bool flagMove;
        public Bullet(GameBoard board,Rectangle startLocation, CharacterDirection direction, List<Character> targets)
        {
            this.step = 3;
            this.location = new Rectangle(startLocation.X + 12, startLocation.Y + 12, 12, 12);
            this.direction = direction;
            this.flagMove = true;
            this.gameBoard = board;
            this.targets = targets;
        }
        public bool HitTarget()
        {
            foreach (Character chr in targets)
            {
                if (this.location.IntersectsWith(chr.CurrentLocation))
                {
                    pl.Play();
                    chr.alive = false;
                    return true;
                }
            }
            foreach (Bullet b in gameBoard.bulls)
            {
                if (this != b && this.Location.IntersectsWith(b.Location))
                {
                    this.flagMove = false;
                    return true;
                }
            }
            if (!gameBoard.CanMove(this.location))
            {
                this.flagMove = false;
            }
            return false;
        }
        bool OutOfBoard()
        {
            if (location.X > gameBoard.SzBoard.Width || location.X < 0 || location.Y > gameBoard.SzBoard.Height || location.Y < 0)
                return true;
            else
                return false;
        }
        public void Shot(object state)
        {
            while (flagMove)
            {
                switch (direction)
                {
                    case CharacterDirection.Down:
                        location.Y += step;
                        break;
                    case CharacterDirection.Left:
                        location.X -= step;
                        break;
                    case CharacterDirection.Right:
                        location.X += step;
                        break;
                    case CharacterDirection.Up:
                        location.Y -= step;
                        break;
                }
                if (HitTarget())
                {
                    flagMove = false;
                }
                if (OutOfBoard())
                {
                    flagMove = false;
                }
                else
                    Thread.Sleep(10);
            }
            lock (gameBoard.bulls)
            {
                gameBoard.bulls.Remove(this);
            }
        }
    }
}
