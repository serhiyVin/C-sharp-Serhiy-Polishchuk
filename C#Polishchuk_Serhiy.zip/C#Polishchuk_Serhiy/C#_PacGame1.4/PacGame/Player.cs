using System;
using System.Collections.Generic;
using System.Text;

namespace PacGame
{
    //����� ������������ ������
    public class Player
    {
        private int score;
        private int lives;
        private int freeLives;
        private bool gameOver;
        public const int START_LIVES = 2;

        public Player() 
        {
            score = 0;
            freeLives = 0;
            gameOver = true;
        }
        public void Reset()
        {
            score = 0;
            lives = START_LIVES;
            freeLives = 0;
            gameOver = false;
        }
        public int Score
        {
            get { return score; }
            set { score = value; }
        }

        public int Lives
        {
            get { return lives; }
            set { lives = value; }
        }

        public int FreeLives
        {
            get { return freeLives; }
            set { freeLives = value; }
        }

        public bool GameOver
        {
            get { return gameOver; }
            set
            {
                gameOver = value;
                if (gameOver) freeLives = 0;
            }
        }
    }
}
