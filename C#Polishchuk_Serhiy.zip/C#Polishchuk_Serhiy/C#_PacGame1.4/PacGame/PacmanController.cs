using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace PacGame
{
    class PacmanController
    {
        private int _gameSpeed = 1; 
        private GameBoard _gameBoard;
        private MainFrame _mainFrame;
        private PacmanView _pacmanView;
        private TankView _tankView;

        private int _countTanks, _width, _height;
        private System.Windows.Forms.Timer tmrMove;
        public PacmanController(int countTanks, int width, int height)
        {
            _countTanks = countTanks;
            _width = width;
            _height = height;
            _tankView = new TankView(1);
            InitializeMainFrame();
            InitializeGameBoard(countTanks, _gameSpeed,new Size(198,198),_mainFrame);
            _pacmanView = new PacmanView(this._gameBoard.Pacman);
            StartGame();

            // 
            // tmrMove
            // 
            this.tmrMove = new System.Windows.Forms.Timer();
            this.tmrMove.Enabled = true; 
            this.tmrMove.Interval = 1;
            this.tmrMove.Tick += new System.EventHandler(this.tmrMove_Tick);
            //   
        }


        private void InitializeGameBoard(int countTanks, int gameSpeed,Size WndSz,MainFrame mainFrm)
        {
            _gameBoard = new GameBoard(countTanks, _gameSpeed, WndSz,mainFrm);
            _gameBoard.SetWalls();
            _gameBoard.InitializeCharacters();
            _gameBoard.Pacman.onEndPlayerTurn += new Pacman.EndPlayerTurnEventHandler(Pacman_onEndPlayerTurn);
            _gameBoard.InitializeThreads();
            _gameBoard._mainFrame = mainFrm;
        }

        void Pacman_onEndPlayerTurn(object Source, EventArgs e)
        {
            _gameBoard.StopCharacters();
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Program Files\Microsoft Visual Studio 8\Projects\PacGame\PacGame\SoundEffects\PacmanEaten.wav");
            player.Play();
            System.Threading.Thread.Sleep(2000);
            if (_gameBoard.Player.Lives==0)
            {
                _gameBoard.Player.GameOver = true;
                _gameBoard.Player.Score = 0;
            }
            else
            {
                _gameBoard.Player.Lives -= 1;
            }
            _gameBoard.ResetCharacters();
            Thread.Sleep(1000);
            if (_gameBoard.Player.GameOver)
            {
                _gameBoard.StopCharacters();
            }
            _gameBoard.MoveCharacters();
        }
        private void InitializeMainFrame()
        {
            _mainFrame = new MainFrame();
            _mainFrame.Paint+=new PaintEventHandler(_mainFrame_Paint);
            _mainFrame.KeyDown += new KeyEventHandler(_mainFrame_KeyDown);

        }

        void _mainFrame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                _gameBoard.Pacman.AttemptedDirection = CharacterDirection.Down;
            }
            else if (e.KeyCode == Keys.Up)
            {
                _gameBoard.Pacman.AttemptedDirection = CharacterDirection.Up;
            }
            else if (e.KeyCode == Keys.Left)
            {
                _gameBoard.Pacman.AttemptedDirection = CharacterDirection.Left;
            }
            else if (e.KeyCode == Keys.Right)
            {
                _gameBoard.Pacman.AttemptedDirection = CharacterDirection.Right;
            }
        }
        void _mainFrame_Paint(object sender, PaintEventArgs e)
        {
            _pacmanView.PaintCharacter(e.Graphics);
            _gameBoard.PaintGameBoard(e.Graphics);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            PacmanController _pacmanController = new PacmanController(3, 300, 300 );
            Application.Run(_pacmanController._mainFrame);
        }

        private void StartGame()
        {
            _gameBoard.MoveCharacters();
        }
        private void ResetGame()
        {

        }
        private void ScoreChanged()
        {

        }
        private void ResetGameBoard()
        {
            if (_board.Player1.GameOver)
            {
                lblStatus.ForeColor = Color.FromArgb(255, 0, 0);
                lblStatus.Text = "GAME OVER";
            }
            else
            {
                lblStatus.ForeColor = Color.FromArgb(255, 255, 0);
                lblStatus.Text = "READY!";
            }
        }
        private void tmrMove_Tick(object sender, EventArgs e)
        {
            _mainFrame.Invalidate();
        }


    }
}
