using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Configuration;
using System.Globalization;

namespace ButtonsRacingApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string cultInfo = ConfigurationManager.AppSettings["CultureInfo"];
            Application.Run(new Form1(new CultureInfo (cultInfo))); 
        }
    }
}