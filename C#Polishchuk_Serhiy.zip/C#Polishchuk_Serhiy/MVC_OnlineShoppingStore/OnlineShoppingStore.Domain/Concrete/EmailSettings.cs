﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingStore.Domain.Concrete
{
    //нужно настроить под свою почту, чтобы данная функция работала
    public class EmailSettings
    {
        public string MailToAddress = "***@gmail.com";
        public string MailFromAddress = "***@gmail.com";
        public bool UseSsl = true;
        public string UserName = "***@gmail.com";
        public string Password = "***";
        public string ServerName = "smtp.gmail.com";
        public int ServerPort = 587;
    }
}
