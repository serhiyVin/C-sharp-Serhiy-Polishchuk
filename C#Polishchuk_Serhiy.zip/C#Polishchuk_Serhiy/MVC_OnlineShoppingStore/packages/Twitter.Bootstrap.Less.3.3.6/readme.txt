Twitter.Bootstrap.Less is moving!

v3.3.6 will be the last release of the Bootstrap Less source under the Twitter.Bootstrap namespace. With new projects moving forward, you should install Bootstrap directly from the Bootstrap.Less namespace maintained by twbs contributors https://www.nuget.org/packages/Bootstrap.Less/
For existing projects, you already have the new Bootstrap package installed by upgrading to this release.

The folder structure of the bootstrap files will remain exactly the same

Any questions or issues? Ask me on twitter @sirkirby or visit https://github.com/twbs/bootstrap/issues/16692 & https://github.com/sirkirby/twitter-bootstrap-nuget/issues/46