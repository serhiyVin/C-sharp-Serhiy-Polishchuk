namespace SvetoforApp
{
    partial class Frame
    {
        /// <summary>
        /// Required designer variable. 
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataView = new System.Windows.Forms.DataGridView();
            this.SimpleSvetofor = new SvetoforControlLibrary.Svetofor();
            this.TrippleSvetofor = new SvetoforControlLibrary.Svetofor();
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataView
            // 
            this.dataView.AllowUserToAddRows = false;
            this.dataView.AllowUserToResizeColumns = false;
            this.dataView.AllowUserToResizeRows = false;
            this.dataView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataView.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataView.Location = new System.Drawing.Point(20, 12);
            this.dataView.MultiSelect = false;
            this.dataView.Name = "dataView";
            this.dataView.ReadOnly = true;
            this.dataView.RowHeadersVisible = false;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataView.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataView.Size = new System.Drawing.Size(168, 86);
            this.dataView.StandardTab = true;
            this.dataView.TabIndex = 1;
            // 
            // SimpleSvetofor
            // 
            this.SimpleSvetofor.BackColor = System.Drawing.SystemColors.ControlDark;
            this.SimpleSvetofor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SimpleSvetofor.CurrentColor = SvetoforControlLibrary.SvetoforColors.Red;
            this.SimpleSvetofor.Location = new System.Drawing.Point(20, 108);
            this.SimpleSvetofor.Name = "SimpleSvetofor";
            this.SimpleSvetofor.Size = new System.Drawing.Size(62, 62);
            this.SimpleSvetofor.State = System.Windows.Forms.CheckState.Checked;
            this.SimpleSvetofor.SvetoforView = SvetoforControlLibrary.SvetoforViews.SimpleSvetoforView;
            this.SimpleSvetofor.TabIndex = 2;
            this.SimpleSvetofor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SimpleSvetofor_MouseClick);
            // 
            // TrippleSvetofor
            // 
            this.TrippleSvetofor.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TrippleSvetofor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TrippleSvetofor.CurrentColor = SvetoforControlLibrary.SvetoforColors.Red;
            this.TrippleSvetofor.Location = new System.Drawing.Point(126, 108);
            this.TrippleSvetofor.Name = "TrippleSvetofor";
            this.TrippleSvetofor.Size = new System.Drawing.Size(62, 162);
            this.TrippleSvetofor.State = System.Windows.Forms.CheckState.Checked;
            this.TrippleSvetofor.SvetoforView = SvetoforControlLibrary.SvetoforViews.TrippleSvetoforView;
            this.TrippleSvetofor.TabIndex = 3;
            this.TrippleSvetofor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TrippleSvetofor_MouseClick);
            // 
            // Frame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(251, 282);
            this.Controls.Add(this.TrippleSvetofor);
            this.Controls.Add(this.SimpleSvetofor);
            this.Controls.Add(this.dataView);
            this.MaximizeBox = false;
            this.Name = "Frame";
            this.Text = "Svetofor";
            ((System.ComponentModel.ISupportInitialize)(this.dataView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataView;
        private SvetoforControlLibrary.Svetofor SimpleSvetofor;
        private SvetoforControlLibrary.Svetofor TrippleSvetofor;


    }
}

