﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SvetoforControlLibrary
{
    //перечисление для определения вида светофора
    public enum SvetoforViews
    {
      SimpleSvetoforView,
      TrippleSvetoforView
    }
    //перечисление для определения текущего цвета светофора
    public enum SvetoforColors
    {
        Red,
        Green,
        Yellow
    }
    //класс представляющий пользовательский елемент управления светофор
    public class Svetofor : UserControl
    {
        //переменная для хранения вида светофора
        SvetoforViews _View;
        //переменная для хранения текущего цвета светофора
        SvetoforColors _CurrentColor;
        //переменная для хранения предыдущего цвета светофора
        SvetoforColors _PrevColor;
        //переменная для хранения текущего вида светофора
        SvetoforView _CurrentView;
        //св-ва для установки и орпеделения
        //вида и цвета светофора
        public SvetoforViews SvetoforView
        {
            get
            {
                return _View; 
            }
            set
            {
                _View = value;
                switch (_View)
                {
                    case SvetoforViews.SimpleSvetoforView:
                        _CurrentView = new SimpleSvetoforView();
                        break;
                    case SvetoforViews.TrippleSvetoforView:
                        _CurrentView = new TrippleSvetoforView();
                        break;
                }
                Invalidate();  
            }
        }
        public SvetoforColors CurrentColor
        {
            get { return _CurrentColor; }
            set { _CurrentColor = value; Invalidate(); }
        }
        public CheckState State
        {
            get 
            {
                if (CurrentColor == SvetoforColors.Red)
                    return CheckState.Checked;
                else if (CurrentColor == SvetoforColors.Yellow)
                    return CheckState.Indeterminate;
                else
                    return CheckState.Unchecked;
            }
            set
            {
                switch (value)
                { 
                    case CheckState.Checked:
                        CurrentColor = SvetoforColors.Red;
                        break;
                    case CheckState.Indeterminate:
                        CurrentColor = SvetoforColors.Yellow;
                        break;
                    case CheckState .Unchecked:
                        CurrentColor = SvetoforColors.Red;
                        break;
                }
            }
        }
        public Svetofor()
        {
            SvetoforView = SvetoforViews.SimpleSvetoforView;
            CurrentColor = SvetoforColors.Red;
            _PrevColor = SvetoforColors.Red;
            InitializeComponent();
        }
        //переопределенный метод перерисовки ел-та управления
        private void Svetofor_Paint(object sender, PaintEventArgs e)
        {
            //установка размера ел-та упр-ния
            this.SetClientSizeCore(_CurrentView.CtrlSize.Width,_CurrentView.CtrlSize.Height);
            //вывод изображения 
            _CurrentView.Draw(e.Graphics,(int)_CurrentColor);
        }
        #region Component Designer generated code
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Svetofor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DoubleBuffered = true;
            this.Name = "Svetofor";
            this.Size = new System.Drawing.Size(148, 148);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Svetofor_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Svetofor_MouseClick);
            this.ResumeLayout(false);

        }
        #endregion
        //обработчик щелчка мыши 
        private void Svetofor_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                //вычисляется текущий цвет светофора и
                //устанавливается следующий цвет
                switch (_CurrentColor)
                {
                    case SvetoforColors.Red:
                        _PrevColor = SvetoforColors.Red;
                        CurrentColor = SvetoforColors.Yellow;
                        break;
                    case SvetoforColors.Yellow:
                        switch (_PrevColor)
                        {
                            case SvetoforColors.Red:
                                CurrentColor = SvetoforColors.Green;
                                break;
                            case SvetoforColors.Green:
                                CurrentColor = SvetoforColors.Red;
                                break;
                        }
                        break;
                    case SvetoforColors.Green:
                        _PrevColor = SvetoforColors.Green;
                        CurrentColor = SvetoforColors.Yellow;
                        break;
                }
            }
        }
    }

}