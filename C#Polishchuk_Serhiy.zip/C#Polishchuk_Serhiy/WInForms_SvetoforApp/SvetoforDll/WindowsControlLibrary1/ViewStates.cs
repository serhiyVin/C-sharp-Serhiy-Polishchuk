using System;
using System.Collections.Generic;
using System.Text;

namespace SvetoforControlLibrary
{
    public enum ViewStates
    {
        SimpleView, 
        TrippleView
    }
}
